#include <stdio.h>
#include <stdlib.h>

int main (){
  printf("this is elf file \n What number Clickcamp is this?: ");
  int f=0;
  while(1){
  	
	scanf("%d",&f);
  
  	if(f==16){
  		printf("We are Clickcamp%d !HEY \n",f);
		break;
  	}
	else {  printf("Nope\n Try please! : \n");
	}
 }
  return 0;
}
